﻿namespace IMBD1
{
    partial class Admin_Movies
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin_Movies));
            this.panel1 = new System.Windows.Forms.Panel();
            this.comboBox_movie_prize = new System.Windows.Forms.ComboBox();
            this.bunifuCustomLabel9 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.textbox_movie_catrgory_id = new System.Windows.Forms.TextBox();
            this.bunifuCustomLabel8 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.textBox_movie_directorid = new System.Windows.Forms.TextBox();
            this.bunifuCustomLabel7 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel6 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button3 = new System.Windows.Forms.Button();
            this.btn_movie_delete = new System.Windows.Forms.Button();
            this.btn_movie_update = new System.Windows.Forms.Button();
            this.btn_movie_add = new System.Windows.Forms.Button();
            this.textBox_movie_numberofviews = new System.Windows.Forms.TextBox();
            this.bunifuCustomLabel5 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.textBox_movie_language = new System.Windows.Forms.TextBox();
            this.bunifuCustomLabel4 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.textBox_movie_rate = new System.Windows.Forms.TextBox();
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.textBox_movie_date = new System.Windows.Forms.TextBox();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.textBox_movie_title = new System.Windows.Forms.TextBox();
            this.combobox_id = new System.Windows.Forms.ComboBox();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.label_movie_title = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.panelLeft = new System.Windows.Forms.Panel();
            this.iconButton_back = new FontAwesome.Sharp.IconButton();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelLeft.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.panel1.Controls.Add(this.comboBox_movie_prize);
            this.panel1.Controls.Add(this.bunifuCustomLabel9);
            this.panel1.Controls.Add(this.textbox_movie_catrgory_id);
            this.panel1.Controls.Add(this.bunifuCustomLabel8);
            this.panel1.Controls.Add(this.textBox_movie_directorid);
            this.panel1.Controls.Add(this.bunifuCustomLabel7);
            this.panel1.Controls.Add(this.bunifuCustomLabel6);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.btn_movie_delete);
            this.panel1.Controls.Add(this.btn_movie_update);
            this.panel1.Controls.Add(this.btn_movie_add);
            this.panel1.Controls.Add(this.textBox_movie_numberofviews);
            this.panel1.Controls.Add(this.bunifuCustomLabel5);
            this.panel1.Controls.Add(this.textBox_movie_language);
            this.panel1.Controls.Add(this.bunifuCustomLabel4);
            this.panel1.Controls.Add(this.textBox_movie_rate);
            this.panel1.Controls.Add(this.bunifuCustomLabel3);
            this.panel1.Controls.Add(this.textBox_movie_date);
            this.panel1.Controls.Add(this.bunifuCustomLabel2);
            this.panel1.Controls.Add(this.textBox_movie_title);
            this.panel1.Controls.Add(this.combobox_id);
            this.panel1.Controls.Add(this.bunifuCustomLabel1);
            this.panel1.Controls.Add(this.label_movie_title);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(277, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(625, 678);
            this.panel1.TabIndex = 2;
            // 
            // comboBox_movie_prize
            // 
            this.comboBox_movie_prize.FormattingEnabled = true;
            this.comboBox_movie_prize.Location = new System.Drawing.Point(258, 528);
            this.comboBox_movie_prize.Name = "comboBox_movie_prize";
            this.comboBox_movie_prize.Size = new System.Drawing.Size(121, 24);
            this.comboBox_movie_prize.TabIndex = 27;
            // 
            // bunifuCustomLabel9
            // 
            this.bunifuCustomLabel9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuCustomLabel9.AutoSize = true;
            this.bunifuCustomLabel9.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel9.ForeColor = System.Drawing.Color.Gold;
            this.bunifuCustomLabel9.Location = new System.Drawing.Point(97, 530);
            this.bunifuCustomLabel9.Name = "bunifuCustomLabel9";
            this.bunifuCustomLabel9.Size = new System.Drawing.Size(150, 32);
            this.bunifuCustomLabel9.TabIndex = 25;
            this.bunifuCustomLabel9.Text = "Prize_Title";
            // 
            // textbox_movie_catrgory_id
            // 
            this.textbox_movie_catrgory_id.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textbox_movie_catrgory_id.Location = new System.Drawing.Point(326, 494);
            this.textbox_movie_catrgory_id.Name = "textbox_movie_catrgory_id";
            this.textbox_movie_catrgory_id.Size = new System.Drawing.Size(121, 22);
            this.textbox_movie_catrgory_id.TabIndex = 24;
            // 
            // bunifuCustomLabel8
            // 
            this.bunifuCustomLabel8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuCustomLabel8.AutoSize = true;
            this.bunifuCustomLabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel8.ForeColor = System.Drawing.Color.Gold;
            this.bunifuCustomLabel8.Location = new System.Drawing.Point(92, 484);
            this.bunifuCustomLabel8.Name = "bunifuCustomLabel8";
            this.bunifuCustomLabel8.Size = new System.Drawing.Size(172, 32);
            this.bunifuCustomLabel8.TabIndex = 23;
            this.bunifuCustomLabel8.Text = "Category_ID";
            // 
            // textBox_movie_directorid
            // 
            this.textBox_movie_directorid.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_movie_directorid.Location = new System.Drawing.Point(326, 382);
            this.textBox_movie_directorid.Name = "textBox_movie_directorid";
            this.textBox_movie_directorid.Size = new System.Drawing.Size(121, 22);
            this.textBox_movie_directorid.TabIndex = 22;
            // 
            // bunifuCustomLabel7
            // 
            this.bunifuCustomLabel7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuCustomLabel7.AutoSize = true;
            this.bunifuCustomLabel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel7.ForeColor = System.Drawing.Color.Gold;
            this.bunifuCustomLabel7.Location = new System.Drawing.Point(97, 382);
            this.bunifuCustomLabel7.Name = "bunifuCustomLabel7";
            this.bunifuCustomLabel7.Size = new System.Drawing.Size(156, 32);
            this.bunifuCustomLabel7.TabIndex = 21;
            this.bunifuCustomLabel7.Text = "Director_ID";
            // 
            // bunifuCustomLabel6
            // 
            this.bunifuCustomLabel6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuCustomLabel6.AutoSize = true;
            this.bunifuCustomLabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel6.ForeColor = System.Drawing.Color.Gold;
            this.bunifuCustomLabel6.Location = new System.Drawing.Point(417, 61);
            this.bunifuCustomLabel6.Name = "bunifuCustomLabel6";
            this.bunifuCustomLabel6.Size = new System.Drawing.Size(97, 32);
            this.bunifuCustomLabel6.TabIndex = 20;
            this.bunifuCustomLabel6.Text = "Poster";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.BackColor = System.Drawing.Color.Silver;
            this.pictureBox1.Image = global::IMBD1.Properties.Resources.iconfinder_men_5925629;
            this.pictureBox1.Location = new System.Drawing.Point(393, 123);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(138, 122);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 19;
            this.pictureBox1.TabStop = false;
            // 
            // button3
            // 
            this.button3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button3.BackColor = System.Drawing.Color.Gold;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.Black;
            this.button3.Location = new System.Drawing.Point(393, 285);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(138, 45);
            this.button3.TabIndex = 18;
            this.button3.Text = "Upload";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // btn_movie_delete
            // 
            this.btn_movie_delete.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_movie_delete.BackColor = System.Drawing.Color.Gold;
            this.btn_movie_delete.FlatAppearance.BorderSize = 0;
            this.btn_movie_delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_movie_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_movie_delete.ForeColor = System.Drawing.Color.Black;
            this.btn_movie_delete.Location = new System.Drawing.Point(402, 602);
            this.btn_movie_delete.Name = "btn_movie_delete";
            this.btn_movie_delete.Size = new System.Drawing.Size(150, 45);
            this.btn_movie_delete.TabIndex = 17;
            this.btn_movie_delete.Text = "Delete";
            this.btn_movie_delete.UseVisualStyleBackColor = false;
            this.btn_movie_delete.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_movie_update
            // 
            this.btn_movie_update.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_movie_update.BackColor = System.Drawing.Color.Gold;
            this.btn_movie_update.FlatAppearance.BorderSize = 0;
            this.btn_movie_update.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_movie_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_movie_update.ForeColor = System.Drawing.Color.Black;
            this.btn_movie_update.Location = new System.Drawing.Point(236, 602);
            this.btn_movie_update.Name = "btn_movie_update";
            this.btn_movie_update.Size = new System.Drawing.Size(150, 45);
            this.btn_movie_update.TabIndex = 16;
            this.btn_movie_update.Text = "Update";
            this.btn_movie_update.UseVisualStyleBackColor = false;
            this.btn_movie_update.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_movie_add
            // 
            this.btn_movie_add.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_movie_add.BackColor = System.Drawing.Color.Gold;
            this.btn_movie_add.FlatAppearance.BorderSize = 0;
            this.btn_movie_add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_movie_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_movie_add.ForeColor = System.Drawing.Color.Black;
            this.btn_movie_add.Location = new System.Drawing.Point(73, 602);
            this.btn_movie_add.Name = "btn_movie_add";
            this.btn_movie_add.Size = new System.Drawing.Size(150, 45);
            this.btn_movie_add.TabIndex = 15;
            this.btn_movie_add.Text = "Add";
            this.btn_movie_add.UseVisualStyleBackColor = false;
            this.btn_movie_add.Click += new System.EventHandler(this.btn_signin_Click);
            // 
            // textBox_movie_numberofviews
            // 
            this.textBox_movie_numberofviews.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_movie_numberofviews.Location = new System.Drawing.Point(326, 440);
            this.textBox_movie_numberofviews.Name = "textBox_movie_numberofviews";
            this.textBox_movie_numberofviews.Size = new System.Drawing.Size(121, 22);
            this.textBox_movie_numberofviews.TabIndex = 14;
            // 
            // bunifuCustomLabel5
            // 
            this.bunifuCustomLabel5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuCustomLabel5.AutoSize = true;
            this.bunifuCustomLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel5.ForeColor = System.Drawing.Color.Gold;
            this.bunifuCustomLabel5.Location = new System.Drawing.Point(73, 440);
            this.bunifuCustomLabel5.Name = "bunifuCustomLabel5";
            this.bunifuCustomLabel5.Size = new System.Drawing.Size(235, 32);
            this.bunifuCustomLabel5.TabIndex = 13;
            this.bunifuCustomLabel5.Text = "Number Of Views";
            // 
            // textBox_movie_language
            // 
            this.textBox_movie_language.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_movie_language.Location = new System.Drawing.Point(212, 308);
            this.textBox_movie_language.Name = "textBox_movie_language";
            this.textBox_movie_language.Size = new System.Drawing.Size(121, 22);
            this.textBox_movie_language.TabIndex = 12;
            this.textBox_movie_language.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // bunifuCustomLabel4
            // 
            this.bunifuCustomLabel4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuCustomLabel4.AutoSize = true;
            this.bunifuCustomLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel4.ForeColor = System.Drawing.Color.Gold;
            this.bunifuCustomLabel4.Location = new System.Drawing.Point(76, 242);
            this.bunifuCustomLabel4.Name = "bunifuCustomLabel4";
            this.bunifuCustomLabel4.Size = new System.Drawing.Size(117, 32);
            this.bunifuCustomLabel4.TabIndex = 11;
            this.bunifuCustomLabel4.Text = "Rate_ID";
            // 
            // textBox_movie_rate
            // 
            this.textBox_movie_rate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_movie_rate.Location = new System.Drawing.Point(212, 242);
            this.textBox_movie_rate.Name = "textBox_movie_rate";
            this.textBox_movie_rate.Size = new System.Drawing.Size(121, 22);
            this.textBox_movie_rate.TabIndex = 10;
            this.textBox_movie_rate.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuCustomLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel3.ForeColor = System.Drawing.Color.Gold;
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(92, 179);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(75, 32);
            this.bunifuCustomLabel3.TabIndex = 9;
            this.bunifuCustomLabel3.Text = "Date";
            // 
            // textBox_movie_date
            // 
            this.textBox_movie_date.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_movie_date.Location = new System.Drawing.Point(212, 179);
            this.textBox_movie_date.Name = "textBox_movie_date";
            this.textBox_movie_date.Size = new System.Drawing.Size(121, 22);
            this.textBox_movie_date.TabIndex = 8;
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.Gold;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(67, 305);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(143, 32);
            this.bunifuCustomLabel2.TabIndex = 7;
            this.bunifuCustomLabel2.Text = "Language";
            // 
            // textBox_movie_title
            // 
            this.textBox_movie_title.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_movie_title.Location = new System.Drawing.Point(212, 123);
            this.textBox_movie_title.Name = "textBox_movie_title";
            this.textBox_movie_title.Size = new System.Drawing.Size(121, 22);
            this.textBox_movie_title.TabIndex = 6;
            // 
            // combobox_id
            // 
            this.combobox_id.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.combobox_id.FormattingEnabled = true;
            this.combobox_id.Location = new System.Drawing.Point(212, 61);
            this.combobox_id.Name = "combobox_id";
            this.combobox_id.Size = new System.Drawing.Size(121, 24);
            this.combobox_id.TabIndex = 5;
            this.combobox_id.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.Gold;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(97, 61);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(42, 32);
            this.bunifuCustomLabel1.TabIndex = 4;
            this.bunifuCustomLabel1.Text = "ID";
            // 
            // label_movie_title
            // 
            this.label_movie_title.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_movie_title.AutoSize = true;
            this.label_movie_title.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_movie_title.ForeColor = System.Drawing.Color.Gold;
            this.label_movie_title.Location = new System.Drawing.Point(97, 123);
            this.label_movie_title.Name = "label_movie_title";
            this.label_movie_title.Size = new System.Drawing.Size(70, 32);
            this.label_movie_title.TabIndex = 2;
            this.label_movie_title.Text = "Title";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // panelLeft
            // 
            this.panelLeft.BackgroundImage = global::IMBD1.Properties.Resources.unnamed51;
            this.panelLeft.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelLeft.Controls.Add(this.iconButton_back);
            this.panelLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelLeft.Location = new System.Drawing.Point(0, 0);
            this.panelLeft.Name = "panelLeft";
            this.panelLeft.Size = new System.Drawing.Size(277, 678);
            this.panelLeft.TabIndex = 1;
            // 
            // iconButton_back
            // 
            this.iconButton_back.BackColor = System.Drawing.Color.Black;
            this.iconButton_back.Flip = FontAwesome.Sharp.FlipOrientation.Normal;
            this.iconButton_back.IconChar = FontAwesome.Sharp.IconChar.Backward;
            this.iconButton_back.IconColor = System.Drawing.Color.Gold;
            this.iconButton_back.IconSize = 26;
            this.iconButton_back.Location = new System.Drawing.Point(0, 0);
            this.iconButton_back.Name = "iconButton_back";
            this.iconButton_back.Rotation = 0D;
            this.iconButton_back.Size = new System.Drawing.Size(57, 40);
            this.iconButton_back.TabIndex = 51;
            this.iconButton_back.UseVisualStyleBackColor = false;
            this.iconButton_back.Click += new System.EventHandler(this.iconButton_back_Click);
            // 
            // Admin_Movies
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(902, 678);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelLeft);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Admin_Movies";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin_Movies";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Admin_Movies_FormClosing);
            this.Load += new System.EventHandler(this.Admin_Movies_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelLeft.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelLeft;
        private System.Windows.Forms.Panel panel1;
        private Bunifu.Framework.UI.BunifuCustomLabel label_movie_title;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private System.Windows.Forms.TextBox textBox_movie_numberofviews;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel5;
        private System.Windows.Forms.TextBox textBox_movie_language;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel4;
        private System.Windows.Forms.TextBox textBox_movie_rate;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        private System.Windows.Forms.TextBox textBox_movie_date;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private System.Windows.Forms.TextBox textBox_movie_title;
        private System.Windows.Forms.ComboBox combobox_id;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btn_movie_delete;
        private System.Windows.Forms.Button btn_movie_update;
        private System.Windows.Forms.Button btn_movie_add;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox textBox_movie_directorid;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel7;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel6;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private FontAwesome.Sharp.IconButton iconButton_back;
        private System.Windows.Forms.TextBox textbox_movie_catrgory_id;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel8;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel9;
        private System.Windows.Forms.ComboBox comboBox_movie_prize;
    }
}